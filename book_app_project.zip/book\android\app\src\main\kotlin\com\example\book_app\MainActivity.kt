package com.example.book_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
