class Book {
  final String id;
  final String title;
  final String author;
  final String coverUrl;
  final double rating;
  final String description;
  final String category;
  final String categoryId;
  final String? audioUrl;
  final String? bookFileUrl;

  Book({
    required this.id,
    required this.title,
    required this.author,
    required this.coverUrl,
    required this.rating,
    required this.description,
    required this.category,
    required this.categoryId,
    this.audioUrl,
    this.bookFileUrl,
  });

  Book copyWith({
    String? id,
    String? title,
    String? author,
    String? coverUrl,
    double? rating,
    String? description,
    String? category,
    String? categoryId,
    String? audioUrl,
    String? bookFileUrl,
  }) {
    return Book(
      id: id ?? this.id,
      title: title ?? this.title,
      author: author ?? this.author,
      coverUrl: coverUrl ?? this.coverUrl,
      rating: rating ?? this.rating,
      description: description ?? this.description,
      category: category ?? this.category,
      categoryId: categoryId ?? this.categoryId,
      audioUrl: audioUrl ?? this.audioUrl,
      bookFileUrl: bookFileUrl ?? this.bookFileUrl,
    );
  }
}

final List<Book> dummyBooks = [
  Book(
    id: '1',
    title: 'تراب الماس',
    author: 'أحمد مراد',
    coverUrl:
        'https://upload.wikimedia.org/wikipedia/ar/2/24/Torab_El_Mas.jpg', // الرابط الجديد من ويكيبيديا
    rating: 4.5,
    category: 'روايات',
    categoryId: '1',
    bookFileUrl:
        'https://docs.google.com/viewerng/viewer?url=https://foulabook.com/storage/book/25799.Foulabook.com.2018-01-20.1516466898.pdf&hl=ar',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    description:
        'تدور أحداث الرواية حول «طه»، مندوب دعاية طبية في شركة أدوية، يعيش حياة رتيبة مع والده القعيد، قبل أن تقع جريمة قتل غامضة تغير حياته تماماً. يبدأ طه في اكتشاف عالم مظلم من الفساد والجريمة من خلال مذكرات والده التي تكشف أسراراً مرعبة عن شخصيات بارزة في المجتمع المصري، ويستخدم «تراب الماس» كوسيلة للانتقام وتطهير المجتمع من المفسدين. تعتبر الرواية مزيجاً من الإثارة والغموض والدراما الاجتماعية، حيث تسلط الضوء على الفساد المتغلغل في طبقات المجتمع المختلفة.',
  ),
  Book(
    id: '2',
    title: 'الفيل الأزرق',
    author: 'أحمد مراد',
    coverUrl:
        'https://m.media-amazon.com/images/S/compressed.photo.goodreads.com/books/1485105416i/16031620.jpg', // الرابط الجديد من أمازون
    rating: 4.8,
    category: 'غموض',
    categoryId: '2',
    description: 'رحلة مثيرة في عالم الأمراض النفسية والغيبيات...',
  ),
  Book(
    id: '3',
    title: 'موسم صيد الغزلان',
    author: 'أحمد مراد',
    coverUrl:
        'https://m.media-amazon.com/images/I/71D8wWbR4QL._AC_UF1000,1000_QL80_.jpg', // الرابط الجديد من أمازون
    rating: 4.2,
    category: 'خيال علمي',
    categoryId: '3',
    description: 'رواية فلسفية تتحدث عن المستقبل والوعي الإنساني...',
  ),
  Book(
    id: '4',
    title: 'أرض الإله',
    author: 'أحمد مراد',
    coverUrl:
        'https://upload.wikimedia.org/wikipedia/ar/thumb/6/6f/%D8%BA%D9%84%D8%A7%D9%81_%D8%B1%D9%88%D8%A7%D9%8A%D8%A9_%D8%A3%D8%B1%D8%B6_%D8%A7%D9%84%D8%A5%D9%84%D9%87.jpeg/330px-%D8%BA%D9%84%D8%A7%D9%81_%D8%B1%D9%88%D8%A7%D9%8A%D8%A9_%D8%A3%D8%B1%D8%B6_%D8%A7%D9%84%D8%A5%D9%84%D9%87.jpeg', // الرابط الجديد من ويكيبيديا
    rating: 4.6,
    category: 'تاريخ',
    categoryId: '4',
    description: 'رواية تاريخية تأخذنا في رحلة إلى مصر القديمة...',
  ),
];
