import 'package:flutter/material.dart';
import 'category_books_screen.dart';

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  final List<Map<String, dynamic>> categories = const [
    {'id': '1', 'name': 'روايات', 'icon': Icons.auto_stories},
    {'id': '2', 'name': 'غموض', 'icon': Icons.psychology},
    {'id': '3', 'name': 'خيال علمي', 'icon': Icons.biotech},
    {'id': '4', 'name': 'تاريخ', 'icon': Icons.history_edu},
    {'id': '5', 'name': 'كتب دينية', 'icon': Icons.menu_book},
    {'id': '6', 'name': 'كتب أطفال', 'icon': Icons.child_care},
    {'id': '7', 'name': 'تنمية بشرية', 'icon': Icons.trending_up},
    {'id': '8', 'name': 'شعر', 'icon': Icons.edit_note},
    {'id': '9', 'name': 'إدارة أعمال', 'icon': Icons.business_center},
    {'id': '10', 'name': 'طب', 'icon': Icons.medical_services},
    {'id': '11', 'name': 'فلسفة', 'icon': Icons.lightbulb_outline},
    {'id': '12', 'name': 'علوم', 'icon': Icons.science},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الأقسام')),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          childAspectRatio: 1,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
        ),
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final category = categories[index];
          return Card(
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => CategoryBooksScreen(
                      categoryId: category['id'],
                      categoryName: category['name'],
                    ),
                  ),
                );
              },
              borderRadius: BorderRadius.circular(12),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    category['icon'],
                    size: 32,
                    color: const Color(0xFFE67E22),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    category['name'],
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
