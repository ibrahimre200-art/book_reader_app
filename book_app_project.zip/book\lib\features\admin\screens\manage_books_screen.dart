import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../../../models/book.dart';
import '../../../core/data_service.dart';

class ManageBooksScreen extends StatefulWidget {
  const ManageBooksScreen({super.key});

  @override
  State<ManageBooksScreen> createState() => _ManageBooksScreenState();
}

class _ManageBooksScreenState extends State<ManageBooksScreen> {
  final DataService _dataService = DataService();
  String _searchQuery = '';

  Future<String?> _pickFile(
    FileType type,
    List<String>? allowedExtensions,
  ) async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: type,
        allowedExtensions: allowedExtensions,
      );

      if (result != null) {
        // في نسخة الويندوز، نحتاج للمسار الكامل للملف
        return result.files.single.path ?? result.files.single.name;
      }
    } catch (e) {
      debugPrint('Error picking file: $e');
    }
    return null;
  }

  void _addOrEditBook([Book? book]) {
    final titleController = TextEditingController(text: book?.title);
    final authorController = TextEditingController(text: book?.author);
    final descController = TextEditingController(text: book?.description);
    final coverUrlController = TextEditingController(text: book?.coverUrl);
    final bookFileUrlController = TextEditingController(
      text: book?.bookFileUrl,
    );
    final audioUrlController = TextEditingController(text: book?.audioUrl);

    String? selectedCategoryId =
        book?.categoryId ?? _dataService.categories.first['id'];
    String? selectedCategoryName =
        book?.category ?? _dataService.categories.first['name'];

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(book == null ? 'إضافة كتاب جديد' : 'تعديل الكتاب'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: coverUrlController,
                  autofocus: true,
                  decoration: const InputDecoration(
                    labelText: 'رابط صورة الغلاف',
                    isDense: true,
                    hintText: 'http://...',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: titleController,
                  decoration: const InputDecoration(
                    labelText: 'عنوان الكتاب',
                    isDense: true,
                  ),
                ),
                TextField(
                  controller: authorController,
                  decoration: const InputDecoration(
                    labelText: 'المؤلف',
                    isDense: true,
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: selectedCategoryId,
                  decoration: const InputDecoration(
                    labelText: 'القسم',
                    isDense: true,
                  ),
                  items: _dataService.categories.map<DropdownMenuItem<String>>((
                    cat,
                  ) {
                    return DropdownMenuItem<String>(
                      value: cat['id'] as String,
                      child: Text(cat['name'] as String),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setDialogState(() {
                      selectedCategoryId = value;
                      selectedCategoryName = _dataService.categories.firstWhere(
                        (c) => c['id'] == value,
                      )['name'];
                    });
                  },
                ),
                const SizedBox(height: 16),
                // التحكم في ملف الكتاب
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: bookFileUrlController,
                        decoration: const InputDecoration(
                          labelText: 'رابط ملف PDF',
                          isDense: true,
                          hintText: 'http://... أو اختر ملفاً',
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(
                        Icons.upload_file,
                        color: Color(0xFFE67E22),
                      ),
                      onPressed: () async {
                        String? filePath = await _pickFile(FileType.custom, [
                          'pdf',
                          'epub',
                        ]);
                        if (filePath != null) {
                          setDialogState(
                            () => bookFileUrlController.text = filePath,
                          );
                        }
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                // التحكم في ملف الصوت
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: audioUrlController,
                        decoration: const InputDecoration(
                          labelText: 'رابط ملف الصوت',
                          isDense: true,
                          hintText: 'http://... أو اختر ملفاً',
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(
                        Icons.audiotrack,
                        color: Color(0xFFE67E22),
                      ),
                      onPressed: () async {
                        String? filePath = await _pickFile(
                          FileType.audio,
                          null,
                        );
                        if (filePath != null) {
                          setDialogState(
                            () => audioUrlController.text = filePath,
                          );
                        }
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: descController,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'وصف الكتاب',
                    isDense: true,
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              onPressed: () {
                final newBook = Book(
                  id: book?.id ?? DateTime.now().toString(),
                  title: titleController.text,
                  author: authorController.text,
                  description: descController.text,
                  coverUrl: coverUrlController.text.isNotEmpty
                      ? coverUrlController.text
                      : 'https://via.placeholder.com/150x220',
                  rating: book?.rating ?? 0.0,
                  category: selectedCategoryName ?? 'عام',
                  categoryId: selectedCategoryId ?? '1',
                  audioUrl: audioUrlController.text.isNotEmpty
                      ? audioUrlController.text
                      : null,
                  bookFileUrl: bookFileUrlController.text.isNotEmpty
                      ? bookFileUrlController.text
                      : null,
                );

                setState(() {
                  if (book == null) {
                    _dataService.addBook(newBook);
                  } else {
                    _dataService.updateBook(newBook);
                  }
                });
                Navigator.pop(context);
              },
              child: Text(book == null ? 'إضافة' : 'حفظ'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _dataService,
      builder: (context, _) {
        final allBooks = _dataService.books;
        final books = _searchQuery.isEmpty
            ? allBooks
            : allBooks.where((b) {
                return b.title.toLowerCase().contains(
                      _searchQuery.toLowerCase(),
                    ) ||
                    b.author.toLowerCase().contains(_searchQuery.toLowerCase());
              }).toList();

        return GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Scaffold(
            appBar: AppBar(
              title: const Text('إدارة الكتب'),
              bottom: PreferredSize(
                preferredSize: const Size.fromHeight(60),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    onChanged: (value) => setState(() => _searchQuery = value),
                    autofocus: true,
                    decoration: InputDecoration(
                      hintText: 'ابحث عن كتاب أو مؤلف...',
                      prefixIcon: const Icon(Icons.search),
                      fillColor: Colors.white,
                      filled: true,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            floatingActionButton: FloatingActionButton(
              onPressed: () => _addOrEditBook(),
              backgroundColor: const Color(0xFFE67E22),
              child: const Icon(Icons.add),
            ),
            body: ListView.builder(
              itemCount: books.length,
              itemBuilder: (context, index) {
                final book = books[index];
                return ListTile(
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: Image.network(
                      book.coverUrl,
                      width: 40,
                      height: 60,
                      fit: BoxFit.cover,
                      errorBuilder: (context, _, __) => const Icon(Icons.book),
                    ),
                  ),
                  title: Text(book.title),
                  subtitle: Text(book.author),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit, color: Colors.blue),
                        onPressed: () => _addOrEditBook(book),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          setState(() => _dataService.deleteBook(book.id));
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }
}
