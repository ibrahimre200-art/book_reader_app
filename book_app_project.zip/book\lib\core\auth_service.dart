class AuthService {
  static bool _isLoggedIn = false;
  static String? _userName;

  static bool get isLoggedIn => _isLoggedIn;
  static String? get userName => _userName;

  static Future<bool> login(String email, String password) async {
    // محاكاة عملية تسجيل الدخول
    await Future.delayed(const Duration(seconds: 1));
    if (email.isNotEmpty && password.length >= 6) {
      _isLoggedIn = true;
      _userName = email.split(
        '@',
      )[0]; // استخدام الجزء الأول من البريد كاسم مستخدم مؤقت
      return true;
    }
    return false;
  }

  static Future<bool> register(
    String name,
    String email,
    String password,
  ) async {
    // محاكاة عملية التسجيل
    await Future.delayed(const Duration(seconds: 1));
    if (name.isNotEmpty && email.isNotEmpty && password.length >= 6) {
      _isLoggedIn = true;
      _userName = name;
      return true;
    }
    return false;
  }

  static void logout() {
    _isLoggedIn = false;
    _userName = null;
  }

  static Future<bool> resetPassword(String email) async {
    // محاكاة عملية استعادة كلمة المرور
    await Future.delayed(const Duration(seconds: 1));
    if (email.contains('@')) {
      return true;
    }
    return false;
  }
}
