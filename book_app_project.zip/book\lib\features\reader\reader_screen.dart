import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import 'dart:io';
import '../../models/book.dart';

class ReaderScreen extends StatefulWidget {
  final Book book;

  const ReaderScreen({super.key, required this.book});

  @override
  State<ReaderScreen> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends State<ReaderScreen> {
  final PdfViewerController _pdfViewerController = PdfViewerController();
  final PdfTextSearchResult _searchResult = PdfTextSearchResult();

  double _fontSize = 18.0;
  Color _backgroundColor = Colors.white;
  Color _textColor = Colors.black87;
  String _fontFamily = 'Cairo';
  bool _isSearchVisible = false;
  final TextEditingController _searchTextController = TextEditingController();

  @override
  void dispose() {
    _pdfViewerController.dispose();
    _searchTextController.dispose();
    super.dispose();
  }

  void _showSettings() {
    bool isPdf = _isPdf();

    if (isPdf) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('إعدادات الخط غير متاحة لملفات PDF')),
      );
      return;
    }
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'إعدادات القراءة',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 24),
                  const Text('حجم الخط'),
                  Slider(
                    value: _fontSize,
                    min: 14,
                    max: 32,
                    activeColor: const Color(0xFFE67E22),
                    onChanged: (value) {
                      setModalState(() => _fontSize = value);
                      setState(() => _fontSize = value);
                    },
                  ),
                  const SizedBox(height: 16),
                  const Text('لون الخلفية'),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildColorOption(
                        Colors.white,
                        Colors.black87,
                        'أبيض',
                        setModalState,
                      ),
                      _buildColorOption(
                        const Color(0xFFF5F5DC),
                        Colors.black87,
                        'ورقي',
                        setModalState,
                      ),
                      _buildColorOption(
                        const Color(0xFF2C3E50),
                        Colors.white,
                        'ليلي',
                        setModalState,
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildColorOption(
    Color bg,
    Color text,
    String label,
    Function setModalState,
  ) {
    bool isSelected = _backgroundColor == bg;
    return GestureDetector(
      onTap: () {
        setModalState(() {
          _backgroundColor = bg;
          _textColor = text;
        });
        setState(() {
          _backgroundColor = bg;
          _textColor = text;
        });
      },
      child: Column(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: bg,
              shape: BoxShape.circle,
              border: Border.all(
                color: isSelected ? const Color(0xFFE67E22) : Colors.grey,
                width: 2,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 12)),
        ],
      ),
    );
  }

  bool _isPdf() {
    return widget.book.bookFileUrl != null &&
        (widget.book.bookFileUrl!.toLowerCase().endsWith('.pdf') ||
            widget.book.bookFileUrl!.toLowerCase().contains('.pdf?'));
  }

  @override
  Widget build(BuildContext context) {
    bool isPdf = _isPdf();

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: isPdf ? Colors.grey[200] : _backgroundColor,
        appBar: AppBar(
          title: _isSearchVisible && isPdf
              ? TextField(
                  controller: _searchTextController,
                  autofocus: true,
                  decoration: const InputDecoration(
                    hintText: 'بحث في الكتاب...',
                    border: InputBorder.none,
                    hintStyle: TextStyle(color: Colors.white70),
                  ),
                  style: const TextStyle(color: Colors.white),
                  onSubmitted: (value) {
                    _searchResult.clear();
                    _pdfViewerController.searchText(value);
                  },
                )
              : Text(widget.book.title),
          actions: [
            if (isPdf) ...[
              IconButton(
                icon: Icon(_isSearchVisible ? Icons.close : Icons.search),
                onPressed: () {
                  setState(() {
                    _isSearchVisible = !_isSearchVisible;
                    if (!_isSearchVisible) {
                      _searchResult.clear();
                      _searchTextController.clear();
                    }
                  });
                },
              ),
              IconButton(
                icon: const Icon(Icons.zoom_in),
                onPressed: () => _pdfViewerController.zoomLevel += 0.25,
              ),
              IconButton(
                icon: const Icon(Icons.zoom_out),
                onPressed: () => _pdfViewerController.zoomLevel -= 0.25,
              ),
            ],
            if (!isPdf)
              IconButton(
                icon: const Icon(Icons.settings),
                onPressed: _showSettings,
              ),
            IconButton(
              icon: const Icon(Icons.bookmark_border),
              onPressed: () {},
            ),
          ],
        ),
        body: isPdf
            ? _buildPdfViewer()
            : SingleChildScrollView(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  children: [
                    Text(
                      widget.book.description * 15, // Dummy content
                      style: TextStyle(
                        fontSize: _fontSize,
                        color: _textColor,
                        fontFamily: _fontFamily,
                        height: 1.8,
                      ),
                      textAlign: TextAlign.justify,
                    ),
                  ],
                ),
              ),
        bottomNavigationBar: isPdf && _isSearchVisible
            ? Container(
                height: 50,
                color: Colors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.navigate_before),
                      onPressed: () => _searchResult.previousInstance(),
                    ),
                    Text(
                      '${_searchResult.currentInstanceIndex} / ${_searchResult.totalInstanceCount}',
                      style: const TextStyle(color: Colors.black),
                    ),
                    IconButton(
                      icon: const Icon(Icons.navigate_next),
                      onPressed: () => _searchResult.nextInstance(),
                    ),
                  ],
                ),
              )
            : null,
      ),
    );
  }

  Widget _buildPdfViewer() {
    String url = widget.book.bookFileUrl!;

    // إذا كان الرابط هو رابط عرض Google Docs، نستخرج الرابط المباشر للملف
    if (url.contains('docs.google.com/viewerng/viewer?url=')) {
      final uri = Uri.parse(url);
      url = uri.queryParameters['url'] ?? url;
    }

    if (url.startsWith('http')) {
      return SfPdfViewer.network(
        url,
        controller: _pdfViewerController,
        onTextSelectionChanged: (PdfTextSelectionChangedDetails details) {
          if (details.selectedText != null &&
              details.selectedText!.isNotEmpty) {
            // يمكن إضافة ميزة نسخ النص أو ترجمته هنا
          }
        },
      );
    } else if (File(url).existsSync()) {
      return SfPdfViewer.file(File(url), controller: _pdfViewerController);
    } else {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.picture_as_pdf, size: 80, color: Colors.red),
            const SizedBox(height: 16),
            Text('عرض ملف PDF: ${widget.book.bookFileUrl}'),
            const Padding(
              padding: EdgeInsets.all(20.0),
              child: Text(
                'ملاحظة: تأكد من صحة مسار الملف أو الرابط المضاف من لوحة التحكم.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey),
              ),
            ),
          ],
        ),
      );
    }
  }
}
