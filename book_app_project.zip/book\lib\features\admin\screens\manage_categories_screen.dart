import 'package:flutter/material.dart';
import '../../../core/data_service.dart';

class ManageCategoriesScreen extends StatefulWidget {
  const ManageCategoriesScreen({super.key});

  @override
  State<ManageCategoriesScreen> createState() => _ManageCategoriesScreenState();
}

class _ManageCategoriesScreenState extends State<ManageCategoriesScreen> {
  final DataService _dataService = DataService();

  void _addOrEditCategory([Map<String, dynamic>? category]) {
    final controller = TextEditingController(
      text: category != null ? category['name'] : '',
    );

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(category == null ? 'إضافة قسم جديد' : 'تعديل القسم'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'اسم القسم'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              if (controller.text.isNotEmpty) {
                setState(() {
                  if (category == null) {
                    _dataService.addCategory(controller.text);
                  } else {
                    _dataService.updateCategory(
                      category['id']!,
                      controller.text,
                    );
                  }
                });
                Navigator.pop(context);
              }
            },
            child: Text(category == null ? 'إضافة' : 'حفظ'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _dataService,
      builder: (context, _) {
        final categories = _dataService.categories;
        return GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Scaffold(
            appBar: AppBar(title: const Text('إدارة الأقسام')),
            floatingActionButton: FloatingActionButton(
              onPressed: () => _addOrEditCategory(),
              backgroundColor: Colors.green,
              child: const Icon(Icons.add),
            ),
            body: ListView.separated(
              itemCount: categories.length,
              separatorBuilder: (context, index) => const Divider(),
              itemBuilder: (context, index) {
                final cat = categories[index];
                return ListTile(
                  leading: const Icon(Icons.folder_open),
                  title: Text(cat['name']!),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit, color: Colors.blue),
                        onPressed: () => _addOrEditCategory(cat),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          setState(
                            () => _dataService.deleteCategory(cat['id']!),
                          );
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }
}
