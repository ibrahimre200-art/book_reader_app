import 'package:flutter/material.dart';

class AllReviewsScreen extends StatelessWidget {
  final String bookTitle;

  const AllReviewsScreen({super.key, required this.bookTitle});

  @override
  Widget build(BuildContext context) {
    // بيانات تجريبية للتعليقات
    final List<Map<String, dynamic>> dummyReviews = [
      {'name': 'محمد علي', 'comment': 'كتاب رائع جداً وأنصح بقراءته بشدة.', 'rating': 5},
      {'name': 'سارة أحمد', 'comment': 'أسلوب الكاتب مميز والقصة مشوقة.', 'rating': 4},
      {'name': 'أحمد محمود', 'comment': 'استمتعت جداً بقراءة هذا الكتاب، يستحق الاقتناء.', 'rating': 5},
      {'name': 'ليلى يوسف', 'comment': 'الرواية جميلة لكن النهاية كانت متوقعة قليلاً.', 'rating': 3},
      {'name': 'عمر خالد', 'comment': 'من أجمل ما قرأت في هذا المجال.', 'rating': 5},
      {'name': 'نور الهدى', 'comment': 'كتاب ملهم جداً ومفيد.', 'rating': 4},
      {'name': 'ياسين حسن', 'comment': 'تجربة قراءة ممتعة للغاية.', 'rating': 5},
      {'name': 'مريم إبراهيم', 'comment': 'لم يعجبني أسلوب السرد في بعض الفصول.', 'rating': 2},
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text('تعليقات $bookTitle'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: dummyReviews.length,
        itemBuilder: (context, index) {
          final review = dummyReviews[index];
          return _buildReviewItem(
            review['name'],
            review['comment'],
            review['rating'],
          );
        },
      ),
    );
  }

  Widget _buildReviewItem(String name, String comment, int rating) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const CircleAvatar(
                radius: 20,
                backgroundColor: Color(0xFFE67E22),
                child: Icon(Icons.person, size: 24, color: Colors.white),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    Row(
                      children: List.generate(
                        5,
                        (index) => Icon(
                          Icons.star,
                          size: 16,
                          color: index < rating ? Colors.amber : Colors.grey[300],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Text(
                'منذ يومين',
                style: TextStyle(color: Colors.grey[500], fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.only(right: 52.0),
            child: Text(
              comment,
              style: TextStyle(color: Colors.grey[800], fontSize: 15, height: 1.4),
            ),
          ),
          const SizedBox(height: 12),
          const Divider(),
        ],
      ),
    );
  }
}
