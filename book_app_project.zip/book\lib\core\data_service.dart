import 'package:flutter/foundation.dart';
import '../models/book.dart';

class DataService extends ChangeNotifier {
  static final DataService _instance = DataService._internal();
  factory DataService() => _instance;
  DataService._internal();

  final List<Book> _books = List.from(dummyBooks);
  final List<Map<String, dynamic>> _categories = [
    {'id': '1', 'name': 'روايات'},
    {'id': '2', 'name': 'تنمية بشرية'},
    {'id': '3', 'name': 'تاريخ'},
    {'id': '4', 'name': 'علوم'},
  ];

  final Map<String, List<Map<String, dynamic>>> _reviews = {};

  List<Book> get books => List.unmodifiable(_books);
  List<Map<String, dynamic>> get categories => List.unmodifiable(_categories);

  List<Map<String, dynamic>> getReviews(String bookId) {
    return _reviews[bookId] ??
        [
          {
            'name': 'محمد علي',
            'comment': 'كتاب رائع جداً وأنصح بقراءته بشدة.',
            'rating': 5,
          },
          {
            'name': 'سارة أحمد',
            'comment': 'أسلوب الكاتب مميز والقصة مشوقة.',
            'rating': 4,
          },
        ];
  }

  void addReview(String bookId, Map<String, dynamic> review) {
    if (!_reviews.containsKey(bookId)) {
      _reviews[bookId] = [
        {
          'name': 'محمد علي',
          'comment': 'كتاب رائع جداً وأنصح بقراءته بشدة.',
          'rating': 5,
        },
        {
          'name': 'سارة أحمد',
          'comment': 'أسلوب الكاتب مميز والقصة مشوقة.',
          'rating': 4,
        },
      ];
    }
    _reviews[bookId]!.insert(0, review);
    notifyListeners();
  }

  // Books Management
  void addBook(Book book) {
    _books.add(book);
    notifyListeners();
  }

  void updateBook(Book updatedBook) {
    final index = _books.indexWhere((b) => b.id == updatedBook.id);
    if (index != -1) {
      _books[index] = updatedBook;
      notifyListeners();
    }
  }

  void deleteBook(String id) {
    _books.removeWhere((b) => b.id == id);
    notifyListeners();
  }

  // Categories Management
  void addCategory(String name) {
    final id = (int.parse(_categories.last['id']!) + 1).toString();
    _categories.add({'id': id, 'name': name});
    notifyListeners();
  }

  void updateCategory(String id, String newName) {
    final index = _categories.indexWhere((c) => c['id'] == id);
    if (index != -1) {
      _categories[index]['name'] = newName;
      notifyListeners();
    }
  }

  void deleteCategory(String id) {
    _categories.removeWhere((c) => c['id'] == id);
    notifyListeners();
  }
}
