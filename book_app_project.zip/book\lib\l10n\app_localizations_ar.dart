// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get appTitle => 'إقرأ لي';

  @override
  String get onboardingTitle => 'يمكنك الآن سماع وقراءة الكتب في إقرأ لي!';

  @override
  String get onboardingSubtitle =>
      'اقرأ واستمع لمؤلفاتك المفضلة بأفضل جودة وتجربة فريدة من نوعها';

  @override
  String get login => 'دخول';

  @override
  String get skip => 'تخطي';

  @override
  String get home => 'الرئيسية';

  @override
  String get search => 'البحث';

  @override
  String get categories => 'الأقسام';

  @override
  String get profile => 'حسابي';

  @override
  String get globalBooks => 'كتب عالمية';

  @override
  String get recommendedBooks => 'كتب ننصح بقراءتها';

  @override
  String get more => 'المزيد';

  @override
  String get aboutBook => 'عن الكتاب';

  @override
  String get read => 'قراءة';

  @override
  String get listen => 'استماع';

  @override
  String get reviews => 'التعليقات';

  @override
  String get seeAll => 'رؤية الكل';
}
